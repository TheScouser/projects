package code;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ManyToOne<String,Integer> mto =new ManyToOne<String,Integer>(); 
		mto.connect("s1", 10);
		mto.connect("s2",20);
		mto.connect("s3", 10);
		//mto.disconnectSource("s3");
		//mto.disconnect(10);
		System.out.println(mto.getSources(10));
	}

}
