package code;


import java.util.*;
public class ManyToOne<M,O> {
	private Map<List<M>,O> map = new HashMap<List<M>,O>();

	/**
	 * Connects the given source with the given target. If this source was
	 * previously connected with another target the old connection is lost.
	 * 
	 * @param source
	 * @param target
	 * @return
	 */
	public void connect(M source, O target) {
		if(containsSource(source)){
			disconnectSource(source);
		}
		if(containsTarget(target)){
			for(List<M> i: map.keySet()){
				if(map.get(i).equals(target)){
					List<M> temp = new ArrayList<M>();
					temp.addAll(i);
					temp.add(source);
					map.remove(i);
					map.put(temp, target);
					return;
				}
			}
		
		}
		else{
			List<M> temp = new ArrayList<M>();
			temp.add(source);
			map.put(temp, target);
		}
	}


	/**
	 * @param source
	 * @return <code>true</code> if the relation contains the given source
	 */
	public boolean containsSource(M source) {
		for(List<M> i :map.keySet()){
			for(M temp : i){
				if(temp.equals(source)){
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * @param target
	 * @return <code>true</code> if the relation contains the given target
	 */
	public boolean containsTarget(O target) {
		for(List<M> i : map.keySet()){
			if(map.get(i).equals(target)){
				return true;
			}
		}
		return false;
	}

	/**
	 * @param source
	 * @return the target with which this source is connected
	 * or null if target does not exist
	 */
	public O getTarget(M source) {
		
		if(containsSource(source)){
			for(List<M> i:map.keySet()){
				if(i.contains(source)){
					return map.get(i);
				}
			}
		}
		return null;
	}

	/**
	 * @param target
	 * @return all the targets that are connected with this source or empty
	 *         collection if there are no sources connected with this target.
	 */
	public Collection<M> getSources(O target) {
		Collection<M> collection = new ArrayList<M>();
		for(List<M> i: map.keySet()){
			if(map.get(i).equals(target)){
				return i;
			}
		}
		return collection;
	}

	/**
	 * Removes the connection between this source and the corresponding target.
	 * Other sources will still point to the same target.
	 * 
	 * The target is removed if this was the only source pointing to it and
	 * {@link #containsTarget(Object)} will return false.
	 * 
	 * @param source
	 */
	public void disconnectSource(M source) {
		for(List<M> i: map.keySet()){
			if(i.contains(source)){
				List<M> temp = new ArrayList<M>();
				temp.addAll(i);
				temp.remove(temp.indexOf(source));
				map.put(temp, map.get(i));
				map.remove(i);
				return;
			}
		}
	}

	/**
	 * Removes the given target from the relation. All the sources that are
	 * pointing to this target are also removed.
	 * 
	 * If you take the "result" of {@link #getSources(target)} and after that
	 * call this method then {@link #containsSource(Object)} will return
	 * <code>false</code> for every object in "result".
	 * 
	 * @param target
	 */
	public void disconnect(O target) {
		for(List<M>i: map.keySet()){
			if(map.get(i).equals(target)){
				map.remove(i);
				return;
			}
		}
	}

	/**
	 * @return a collection of the targets.
	 */
	public Collection<O> getTargets() {
		Collection<O> collection = map.values();
		
		
		return collection;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((map == null) ? 0 : map.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		ManyToOne other = (ManyToOne) obj;
		if (map == null) {
			if (other.map != null) {
				return false;
			}
		} else if (!map.equals(other.map)) {
			return false;
		}
		return true;
	}
	
}
